#!usr/bin/env python

from view import View


def main():
    View()


main()

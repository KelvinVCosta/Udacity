--TABLES NAMES
---- articles
---- authors
---- log

-- GET ALL FROM
SELECT * FROM $table;

-- Count quantity of views
SELECT COUNT(path)QTY_VIEWS FROM log WHERE status = '200 OK';

-- Count quantity of views of each article
SELECT path, COUNT(path)QTY_VIEWS FROM log WHERE status = '200 OK'
AND path like '/article/%' GROUP BY path ORDER BY QTY_VIEWS DESC;

-- Views qty by article removing '/article/'
SELECT REPLACE(path, '/article/', '')TITLE, COUNT(path)QTY_VIEWS
FROM log WHERE status = '200 OK' AND path like '/article/%'
GROUP BY path ORDER BY QTY_VIEWS DESC

-- Select article's title
SELECT title FROM articles;

-- Get which author wrote which article
SELECT authors.name, articles.title FROM authors JOIN articles ON
authors.id = articles.author ORDER BY authors.name;

--Get articles views quantity
SELECT articles.title, COUNT(log.path)QTY_VIEWS
FROM articles INNER JOIN log
    ON slug = replace(path, '/article/', '')
GROUP BY articles.title;

--Top 3 articles with most views
SELECT articles.title, COUNT(log.path)QTY_VIEWS
FROM articles INNER JOIN log
    ON slug = replace(path, '/article/', '')
GROUP BY articles.title
ORDER BY QTY_VIEWS
LIMIT 3;

-- Get total of each status by date
SELECT CAST(time AS DATE)DATE, status, count(status)TOTAL
FROM log
GROUP BY DATE, status;

-- Get total of logs by date
SELECT CAST(time AS DATE)DATE, COUNT(status)
FROM log
GROUP BY DATE;


--? Which are the 3 articles with most views from all times?
SELECT articles.title, COUNT(log.path)QTY_VIEWS
FROM articles INNER JOIN log
    ON slug = replace(path, '/article/', '')
WHERE log.status = '200 OK'
GROUP BY articles.title
ORDER BY QTY_VIEWS
LIMIT 3;

--? Which are the authors of the 3 articles?
SELECT articles.title, authors.name, COUNT(log.path)QTY_VIEWS
FROM articles
  INNER JOIN log
    ON slug = replace(path, '/article/', '')
  INNER JOIN authors
    ON articles.author = authors.id
WHERE log.status = '200 OK'
GROUP BY articles.title, authors.name
ORDER BY QTY_VIEWS
LIMIT 3;

--total logs no dia
SELECT
  CAST(time AS DATE) AS DATE,
  COUNT(status) AS TOTAL_STATUS
FROM log
GROUP BY DATE
ORDER BY DATE;

-- total de erros no dia
SELECT
  CAST(time AS DATE) AS DATE,
  status,
  COUNT(status) AS TOTAL_STATUS
FROM log
WHERE log.status <> '200 OK'
GROUP BY DATE, status
ORDER BY DATE, status;

-- Testing
SELECT
	CAST(time as date)DATE,
	CAST(
      SUM(
          CASE WHEN status = '404 NOT FOUND' THEN 1 ELSE 0 END
      ) AS DECIMAL(10,2)) / SUM(CASE WHEN status IS NOT NULL THEN 1 ELSE 0 END)
FROM log
GROUP BY DATE
HAVING
	CAST(
      SUM(
          CASE WHEN status = '404 NOT FOUND' THEN 1 ELSE 0 END
      ) AS DECIMAL(10,2)) / SUM(CASE WHEN status IS NOT NULL THEN 1 ELSE 0 END) > 0.01

--? Which days got more than 1% with errors?
SELECT
	CAST(time as date) AS DATE,
	CAST(
      CAST(
      100 * SUM(
          CASE WHEN status = '404 NOT FOUND' THEN 1 ELSE 0 END
      ) AS DECIMAL(10,2))
  / SUM(
      CASE WHEN status IS NOT NULL THEN 1 ELSE 0 END)
  AS DECIMAL(3,2)) AS PERCENTAGE,
  SUM(CASE WHEN status = '404 NOT FOUND' THEN 1 ELSE 0 END) AS TOTAL_ERR,
  SUM(CASE WHEN status IS NOT NULL THEN 1 ELSE 0 END) AS TOTAL_LOGS
FROM log
GROUP BY DATE
HAVING
	CAST(
      SUM(
          CASE WHEN status = '404 NOT FOUND' THEN 1 ELSE 0 END
      ) AS DECIMAL(10,2)) / SUM(CASE WHEN status IS NOT NULL THEN 1 ELSE 0 END) > 0.01
ORDER BY DATE



create view totaldia as
  SELECT (log."time")::date AS date,
    count(log.status) AS total_status
   FROM log
  GROUP BY ((log."time")::date)
  ORDER BY ((log."time")::date);


create function "overlaps"(time without time zone, interval, time without time zone, time without time zone)
  returns boolean
immutable
cost 1
language sql
as $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;

comment on function "overlaps"(time without time zone, interval, time without time zone, time without time zone)
is 'intervals overlap?';


Check if these files exist and are not empty:
  entertainment_center.py
  fresh_tomatoes.py
  media.py

This files were created using Debian 9, so you will see:
#!/usr/bin/python
#coding: utf-8

In case you are not using Linux (or Mac) as well, erased those lines
If you are, you can use chmod +x entertainment_center.py to turn it runnable using

If all is right, run the entertaiment_center.py on the command line

Windows: >python entertainment_center.py
Linux/Mac: same as windows or $./entertainment_center.py
